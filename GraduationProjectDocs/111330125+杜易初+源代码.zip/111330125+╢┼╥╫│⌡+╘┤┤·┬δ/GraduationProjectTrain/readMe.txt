1.html网页下载到本地，给出是否相关的标签。
2.解析html为Doc
3.卡方检验提取出一些term作为特征空间。
4.对Doc计算它的特征向量。

otherFilesSample可放在c盘根目录下。
运行/GraduationProject/src/com/likeyichu/test/Test.java可以看效果。