package com.likeyichu.doc;

public class WebPage {
	/**文章id*/
	public int id;
	
	/**提取的title  */
	public String title;
	
	/**提取的正文  */
	public String content;
	
	/**是否为正面样例*/
	public boolean isPositive;
}
