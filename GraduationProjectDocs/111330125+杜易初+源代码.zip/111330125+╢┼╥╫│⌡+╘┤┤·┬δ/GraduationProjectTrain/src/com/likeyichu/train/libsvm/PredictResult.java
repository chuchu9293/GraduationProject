package com.likeyichu.train.libsvm;

public class PredictResult {
	public boolean isPositive;
	public double degree;
}
